//
//  main.swift
//  buoi2
//
//  Created by Nguyen Thanh Long on 01/07/2023.
//

import Foundation

// cau 1: Viết chương trình nhập vào số nguyên n. Hỏi:
//n là số nguyên dương hay không?
//n có phải là số chẵn hay không?
//n có chia hết cho 5 hay không?
//n có phải là số nguyên tố hay không?
print("Nhap vao só n: ", terminator: "")
let n = Int(readLine()!)!
// check xem n co phai la so duong khong
if(n>0){
    print("\(n) la so nguyen duong")
}
else{
    print("\(n) khong la so nguyen duong")
}
// check n co phai la so chan khong
if(n%2 == 0){
    print("\(n) la so chan")
}
else{
    print("\(n) la so le")
}
// check n co chia het cho 5 ko
if(n%5 == 0){
    print("\(n) chia hết cho 5")
}
else{
    print("\(n) không chia hết cho 5")
}
//n có phải là số nguyên tố không
var count = 0
for i in 1..<n{
    if(n%i == 0){
        count += 1
    }
}
if(count == 1){
    print("\(n) là số nguyên tố")
}
else{
    print("\(n) không là số nguyên tố")
}



//########################################################################
print("============================")
//Câu 2, Nhập 3 giá trị nguyên dương a, b, c. Kiểm tra xem a, b, c có phải là 3 cạnh của tam giác không?
//Nếu là 3 cạnh của tam giác thì tính diện tích của tam giác.
//Nếu không phải là tam giác in ra “a, b, c không phải là 3 cạnh của tam giác”

var s = 0.0

print("Nhập vào cạnh thứ nhất của tam giác: ", terminator: "")
let a = Double(readLine()!)!

print("Nhập vào cạnh thứ hai của tam giác: ", terminator: "")
let b = Double(readLine()!)!

print("Nhập vào cạnh thứ ba của tam giác: ", terminator: "")
let c = Double(readLine()!)!

let p = (a + b + c) / 2
let diff1 = p - a
let diff2 = p - b
let diff3 = p - c

if a + b > c && a + c > b && b + c > a {
    print("3 cạnh trên là cạnh của 1 tam giác")
    s = sqrt(p * diff1 * diff2 * diff3)
    print("Diện tích của tam giác là: \(s)")
} else {
    print("3 cạnh trên không là cạnh của 1 tam giác")
}
//cau 3 Nhập một năm công lịch bất kỳ , kiểm tra xem năm đó có phải năm nhuận hay không.
print("============================")

print("Nhap vao nam: ", terminator: "")
let year = Int(readLine()!)!

if year%4 == 0{
    print("day la nam nhuận")
}
else{
    print("day la năm không nhuận")
}
// Câu 4
//Nhập vào thời điểm T gồm 3 số theo dạng : “Giờ : Phút : Giây” và 1 số nguyên X <= 10000
//Hỏi sau X giây kể từ thời điểm T thì thời gian là bao nhiêu ?
//Hãy in ra theo dạng “Giờ : Phút : Giây”
print("============================")
print("Nhap vao giờ: ", terminator: "")
var hour = Int(readLine()!)!
print("Nhap vao phút: ", terminator: "")
var minute = Int(readLine()!)!
print("Nhap vao giây: ", terminator: "")
var second = Int(readLine()!)!
print("nhap vào số nguyên X : ", terminator: "")
let X = Int(readLine()!)!

var curentTime = hour*3600 + minute*60 + second
var nextTime = curentTime + X
hour = nextTime / 3600
minute = (nextTime % 3600) / 60
second = (nextTime % 3600) % 60
print("Sau \(X) giây thì thời gian hiện tại là: \(hour): \(minute): \(second)")
// cau 5: Tìm số n bé nhất sao cho n! lớn hơn một số m cho trước (m nhập từ bàn phím).

print("============================")
var min_n = 0
print("nhập vào số m: ", terminator: "")

let m = Int(readLine()!)!
for n in 1..<m{
    var giaithua = 1
    for i in 1...n{
        giaithua *= i

    }

    if giaithua > m{
        min_n = n
        break
    }
}
print("số bé nhất sao cho giai thừa của nó lớn hơn một số \(m) là: \(min_n)")

// câu 6: Viết chương trình vẽ một tam giác cân bằng các dấu * với chiều cao nhập từ bàn phím (chiều cao lớn hơn 1

print("Nhap vao canh cua tam giac: ")
let width = Int(readLine()!)!
let height = Int(round(Double(width) / 2))
print(height)
var right: [Int] = [height]
var left :[Int] = []

for i in 1...height {
    for j in 1...width{
        if j>height - i && j < height + i{
            print("*", terminator: " ")
        }
        else{
            print(" ", terminator: " ")
        }
    }
    print("\n")
}


// câu 7

//Viết chương trình vẽ một chữ X bằng các dấu * với chiều cao nhập từ bàn phím (chiều cao lớn hơn 0 và là số lẻ)
//
//    *   *
//     * *
//      *
//     * *
//    *   *

var height_x = 0
print("Nhap vao chieu cao của x: ", terminator: "")
while(true){
    height_x = Int(readLine()!)!
    if height_x < 0{
        print("nhập lại vì là số âm")
    }
    else if height_x % 2 == 0{
        print("Chiều cao phải là số lẻ")
    }
    else{
        break
    }
}
let center_x = Int(round(Double(height_x) / 2))
for i in 1...height_x{
    for j in 1...height_x{
        if j == height_x - i + 1 || j == i{
            print("*", terminator: " ")
        }
        else{
            print(" ", terminator: " ")
        }
    }
    print("\n")
}

// câu 8
// Viết chương trình nhập vào số nguyên dương N (N<=32767), in ra màn hình những số hoàn hảo nhỏ hơn N (số hoàn hảo là số bằng tổng các ước số của nó mà không kể chính nó)
var num = 0
print("Nhap so nguyen duong n: ", terminator: "")
while(true){
    num = Int(readLine()!)!
    if(num<=0){
        print("nhap lai")
    }
    else{ break}
}
var array:[Int] = []
for i in 1...num{
    var sum = 0
    for j in 1..<i{
        if i%j==0{
            sum += j
        }
    }
    if sum == i{
        array.append(i)
    }
}
print("các số hoanf hảo là: \(array)")

// câu 9
//Vẽ hình chữ nhật rỗng
//
//* * * * * * *
//*           *
//*           *
//* * * * * * *

var width1 = 0
var height1 = 0
while(true){
    print("Nhập vào chiều cao của hình chữ nhật: ", terminator: "")
    height1 = Int(readLine()!)!
    print("Nhap vào chiều rộng của hình chữ nhật: ", terminator: "")
    width1 = Int(readLine()!)!

    if width < 0 || height < 0{
        print("nhập lại do chiều cao phải lớn hơn 0")
    }
    else{ break}
}
for i in 1...height{
    for j in 1...width{
        if(i==1 || i == height || j==1 || j == width){
            print("*", terminator: " ")
        }
        else{
            print(" ", terminator: " ")
        }
    }
    print()
}

// câu 10
//Vẽ tam giác cân ngược
//* * * * * * *
//  * * * * *
//    * * *
//      *
var heightOfTriangle = 0
while(true){
    print("Nhập vào chiều cao của tam giác: ", terminator: "")
    heightOfTriangle = Int(readLine()!)!
   
    if heightOfTriangle < 0 {
        print("nhập lại do chiều cao phải lớn hơn 0")
    }
    else{ break}
}
for i in 1...heightOfTriangle{
    for _ in 1...i{
        print(" ", terminator: " ")
    }
    for _ in 1...(2*(heightOfTriangle - i) + 1){
        print("*", terminator: " ")
    }
    print()
}




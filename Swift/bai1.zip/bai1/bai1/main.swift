//
//  main.swift
//  bai1
//
//  Created by Nguyen Thanh Long on 29/06/2023.
//

import Foundation

//Cho một chuỗi, in ra độ dài của chuỗi đó.
//Cho một chuỗi, in ra chuỗi đảo ngược của nó.
//Cho hai chuỗi, kiểm tra xem chuỗi thứ nhất có chứa chuỗi thứ hai hay không.
//Khai báo một biến kiểu Int và gán cho nó giá trị là 10.
//Cho xâu: “cộng hoà xã hội chủ nghĩa việt nam”, in ra chuỗi in hoa tương ứng.
//Cho một chuỗi và một từ khoá. Kiểm tra xem chuỗi có chứa từ khoá đó hay không.
//Cho bán kính hình cầu, tính và in ra diện tích, thể tích của hình cầu đó.
//Tính tổng của bình phương 2 số a, b cho trước.
//Cho một mảng string, nối các phần tử trong mảng với nhau bằng ký tự gạch dưới (_).
//Cho một chuỗi bất kỳ có độ dài lớn hơn 20. In ra chuỗi với cách viết rút gọn chỉ hiển thị 5 ký tự đầu và cuối.

// Cau 1:
var str = "Hom nay là thu 6"
print("Do dai cua chuoi la: \(str.count)")
 
// cau 2:
print("Chuoi dao nguoc cua chuoi \"\(str)\" la \"\(String(str.reversed()))\"")

//cau 3
var str1 = "hom nay la thu 6"
var str2 = "hom nay"

let check = str1.contains(str2) ? "Chuoi 1 chứa chuỗi 2" : "Chuoi 1 khong chứa chuỗi 2"
print(check)

//cau 4
var a = 10

// cau 5
var str3 = "cộng hoà xã hội chủ nghĩa việt nam"
print("Chuoi \"\(str3) \" chuyển sang in hoa la: \(str3.uppercased())")


// cau 6
str = "This is a sample string"
let keyword = "sample"

let check2 = str.contains(keyword) ? "Chuỗi chứa từ khoá." : "Chuỗi không chứa từ khoá."
print(check2)



// cau 7
let r = 3
let PI = Double.pi
let V = 4.0/3 * PI * pow(Double(r), 3)
print("The tich hinh cau là: \(V)")
// cau 8
let num1 = 5
let num2 = 10
print("Tong binh phương của 2 số là: \(Int(pow(Double(num1),2) + pow(Double(num2),2)))")
// cau 9: Cho một mảng string, nối các phần tử trong mảng với nhau bằng ký tự gạch dưới (_).

var str5 = "Hom nay la thu 6"
let words = str.components(separatedBy: " ")
str5 = words.joined(separator: "_")
print(str5)


// cau 10

let str6 = "This is a sample string with 20 words"

print("chuỗi với cách viết rút gọn chỉ hiển thị 5 ký tự đầu và cuối: \(str6.prefix(5))...\(str6.suffix(5))")

//
//  main.swift
//  buoi3
//
//  Created by Nguyen Thanh Long on 04/07/2023.
//

import Foundation
// tính tổng các chữ số trong 1 số
//var number = 38
//var sum = 0
//while number > 0 {
//    var lastnamber = number%10
//    sum += lastnamber
//    number = number/10
//}
//print("Tổng các chữ số trong số \(number) là: \(sum)")
//
//
////Giải phương trình bậc 2: ax2 + bx + c = 0
//var a : Double = 1000
//var b: Double = 20
//var c : Double = 30
//
//if(a == 0){
//    if(b<0){
//        print("Phương trình vô nghiệm")
//    }
//    else{
//        print("Phương trinhg có nghiệm: \(Double(c)/Double(b))")
//    }
//}
//else{
//    var delta: Double = b*b - 4*a*c
//    if(delta < 0){
//        print("Phương trình vô nghiệm")
//    }
//    else if(delta == 0){
//        print("Phương trình có nghiệm kép: x = \(Double(-b)/2*Double(a))")
//    }
//    else{
//        print("Phương trinhf có 2 nghiệm phân biệt")
//        var x1 = -Double(b) - sqrt(delta) / 2*Double(a)
//        var x2 = -Double(b) - sqrt(delta) / 2*Double(a)
//        print(x1)
//        print(x2)
//
//    }
//}

// câu 3

// tạm thời em chưa hiểu giá mở cửa là gì nên để mặc định cứ mở cửa xe là mất bằng đấy tiền

var dic2: [Int: [Int: [Double]]] = [
    1: [1: [14500, 12000], 2: [16000, 12700], 3: [17000, 14300]],
    2: [1: [17600, 14500], 2: [19600, 17100]],
    3: [1: [17100, 13600], 2: [19100, 15100]],
    4: [1: [17600, 14400], 2: [19600, 16200], 3: [14300, 12300]],
    5: [1: [12000, 12000], 2: [13000, 13000], 3: [14500, 14500]],
    6: [1: [13500, 11500], 2: [14500, 12500]],
    7: [1: [15500, 12500]]
]

func feeEntrence(_ carBrand: Int, _ carType: Int) -> Int{
    var fee = 0
    if(carBrand == 1){
        fee = 20000
    }
    else if(carBrand == 2 && carType == 1){
        fee = 11000
    }
    else if(carBrand == 2 && carType == 2){
        fee = 12000
    }
    else if(carBrand == 3){
        if(carType == 1){
            fee = 11000
        }
        else{
            fee = 12000
        }
    }
    else if(carBrand == 4){
        if(carType == 1){
            fee = 20000
        }
        else if(carType == 2){
            fee = 20000
        }
        else{
            fee = 20000
        }
    }
    else if(carBrand == 5){
        if(carType == 1){
            fee = 20000
        }
        else if(carType == 2){
            fee = 20000
        }
        else{
            fee = 20000
        }
    }
    else if(carBrand == 6){
        if(carType == 1){
            fee = 20000
        }
        else{
            fee = 20000
        }
    }
    else{
        fee = 20000
    }
    return fee
}
func cal(_ carBrand: Int, _ carType: Int, _ distance: Int) -> Double {
    var servicePrice: Double = 0.0
    var fee = feeEntrence(carBrand, carType)
    if let brandData = dic2[carBrand], let typeData = brandData[carType] {
        if distance < 30 {
            servicePrice = Double(fee) + Double(distance) * typeData[0]
        } else {
            servicePrice = Double(fee) + 30 * typeData[0] + Double(distance - 30) * typeData[1]
        }
    }
    
    return servicePrice
}

var dic: [Int: [String]] = [
    1: ["4 chỗ nhỏ", "4 chỗ lớn", "7 chỗ"],
    2: ["4 chỗ", "7 chỗ"],
    3: ["4 chỗ", "7 chỗ"],
    4: ["xe Vios", "Xe Innova", "xe Eco"],
    5: ["4 chỗ nhỏ", "4 chỗ lớn", "7 chỗ"],
    6: ["4 chỗ nhỏ", "4 chỗ lớn"],
    7: ["4 chỗ (Vifnast VF e34)"]
]

print("==================== Các hãng xe hiện có ========================")
print("1. Mai Linh")
print("2. Vinasun")
print("3. VinaTaxi")
print("4. Group")
print("5. G7")
print("6. Sao mai")
print("7. GSM")
print("Mời chọn hãng xe: ", terminator: "")
var hangxe = Int(readLine() ?? "1")!

if let loaixe = dic[hangxe]{
    for (index, value) in loaixe.enumerated(){
        print("\(index + 1): \(value)")
    }
}
print("Mời chọn loại xe: ")
var chonxe = 0

while true {
    if let input = readLine(), let choice = Int(input), choice >= 1 && choice <= dic[hangxe]!.count {
        chonxe = choice
        break
    } else {
        print("Vui lòng nhập một lựa chọn hợp lệ.")
    }
}

let servicePrice = cal(hangxe, chonxe, 35)
let str = String(Int(servicePrice))
var result = ""

var index = str.count - 1
while index >= 0 {
    let start = str.index(str.startIndex, offsetBy: max(index - 2, 0))
    let end = str.index(str.startIndex, offsetBy: index)
    let substring = String(str[start...end])
    
    result = substring + " " + result
    
    index -= 3
}

print("Giá dịch vụ: \(result)")

//
//  main.swift
//  buoi3
//
//  Created by Nguyen Thanh Long on 04/07/2023.
//

import Foundation

func isLeapYear(_ year: Int) -> Bool {
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0
}

func Time(_ day: Int, _ month:Int, _ year: Int){
    var previousDay = day - 1
    var previousMonth = month
    var previousYear = year
    
    var nextDay = day + 1
    var nextMonth = month
    var nextYear = year
    let dayOfMonth = [31, isLeapYear(year) ? 29 : 28,31,30,31,30,31,31,30,31,30,31 ]
    if nextDay > dayOfMonth[month-1]{
        nextDay = 1
        nextMonth = month + 1
        
        if nextMonth > 12{
            nextMonth = 1
            nextYear = year + 1
        }
    }
    if previousDay < 1{
        if month>1{
            previousDay = dayOfMonth[month - 1]
        }
       previousDay = 31
        previousMonth = month - 1
        if(previousMonth < 1){
            previousMonth = 12
            previousYear = year - 1
        }
    }
    print("ngay tiep theo la:\(nextDay)/\(nextMonth)/\(nextYear) ")
    print("ngay tiep theo la:\(previousDay)/\(previousMonth)/\(previousYear) ")
}

Time(30,6,2000)
